#ifndef _RENDER_H
#define _RENDER_H

struct slurp_output;

void render(struct slurp_output *output);

#endif
